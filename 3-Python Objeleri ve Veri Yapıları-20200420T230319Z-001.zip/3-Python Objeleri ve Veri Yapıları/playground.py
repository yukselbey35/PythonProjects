x = '10'
y = '20'

x = y

y = '5'

print(x)
print(y)




# x = ["apple", "banana"]
# y = ["apple", "banana"]

# y = x

# print(x is y)

# x[0] = 'grape'

# print(x is y)

# print(x)
# print(y)
