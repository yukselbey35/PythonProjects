message = 'Hello There. My name is Sadık Turan'.split()
# print(message[0])

# my_list = [1,2,3]
# my_list = ['bir',2, True, 5.6]
# print(my_list)

list1 = ['one','two','there']
list2 = ['four','five','six']

numbers = list1 + list2
print(numbers)
print(len(numbers))
print(message[0])
print(numbers[2])

userA = ['Sadık', 36]
userB = ['Çınar', 2]

users = [userA, userB]

print(userA)
print(userB)
print(users)

print(users[0][0])



